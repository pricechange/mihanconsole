============== price change =====================================

Plugin Name: price change
Plugin URI: https://mihanconsole.ir/docs/pricechange
Description: Change the price of "$ 0" to the word free with this plugin!
Author: mihan console
Author URI: https://mihanconsole.ir/
Version: 1.0
Tags: WooCommerce, Zero price change
Requires at least: 5.3
Tested up to: 5.5
Requires PHP: 7.0
Stable tag: 4.6.1
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

============== Description ======================================
Price change plugin for WooCommerce products, with the help of
which you can change the price of $ 0 into a free word without
the need for anything else!

============== Documentation ====================================

To read and study the documents, refer to the mihan console
website at "https://mihanconsole.ir/docs/pricechange".
=================================================================
How to install the plugin :

1- Go to the WordPress Dashboard ==> Install the plugin 
2- Upload the plugin.
3- After installing the plugin, click the Activate button
=================================================================
Plugin support
If you have a problem with the plugin or need help, visit the
mihan console site and send a ticket!
=================================================================